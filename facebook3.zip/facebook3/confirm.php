<?php
include('connect_DB.php');
session_start();
if($_POST){
    //add the friend
    $sql1 = "insert into relation (`from`,`to`,status)values ('" . $_POST['me'] . "','" . $_POST['send'] . "','" . $_POST['status']. "')";
    
    $sql2 = "insert into relation (`from`,`to`,status)values ('" . $_POST['send'] . "','" . $_POST['me'] . "','" . $_POST['status']. "')";

    $conform1= $connect->query($sql1);
    $conform2 = $connect->query($sql2);
// delete request
    $sql3 = "delete from relation where status ='P' and `from` = " .$_POST['send'] ." and `to` = ".$_POST['me'];
    $delete = $connect->query($sql3);
    header('Location:allfriends.php');

}