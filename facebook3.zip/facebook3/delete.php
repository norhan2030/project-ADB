<?php

require('connect_DB.php');
session_start();
$sq2 = "delete from relation where status ='P' and `from` = " .$_POST['send'] ." and `to` = ".$_POST['me'];
 $delete = $connect->query($sq2);
header('Location:allfriends.php');