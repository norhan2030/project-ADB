<?php
require ('connect_DB.php');
session_start();
$idCommand = "select user_ID from users where email = '" . $_SESSION['email'] . "'";
$id = $connect->query($idCommand);
$idu = $id->fetch_assoc();
$user_id = $idu['user_ID'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Freinds</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.min.css">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="css/messenger.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&family=Roboto:wght@100;300;500&display=swap" rel="stylesheet"> -->
</head>
<body>
  <div class="page">
    <div class="left"> 
      <a href="index.php"><i class="fa-brands fa-facebook" id="face-logo"></i></a>
      <h6>Home</h6>
      <ul>
        <li><a href="messenger.html"><i class="fa-brands fa-facebook-messenger"></i></a></li>
        <li><a href="notifucation.html"><i class="fa-solid fa-bell"></i></a></li>
        <li><a href="allfriends.php"><i class="fa-solid fa-user-group"></i></a></li>
        <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i></a></li>
      </ul>

    </div>
    <div class="center-page">
      
    <div class="nav">
      <div class="all-item">
        <div class="choosen">
          <a href="#"><button id="bt1">Friends</button></a>
          <a href="#"><button id="bt2">Friend Request</button></a>
        </div>
          <div  id="nav1">
            <h6>Freinds</h6>
            <div class="search">
              <form action="allfriends.php" method="post">
                <input type="text"id="search" placeholder="search" name="search">
                <i class="fa-solid fa-magnifying-glass" id="icon-search"></i>
                <input type="submit" value="">
              </form>
            </div> 
            <!-- <div class="corner">
                <div class="user">
                    <img src="images/d.jfif" id="profile-foto">
                    <p>nour mohmed</p>
                </div>
                <div class="search">
                    <input type="text"id="search" placeholder="search">
                    <i class="fa-solid fa-magnifying-glass" id="icon-search"></i>
                </div>  
            </div> -->
            <div class="messages">
              <ul id="mes-frinds">
                <?php
                  if($_POST){
                    $search=$_POST['search'];
                    
                    $id_friends_command="select `to` from relation where status = 'F' and `from` = ".$user_id;
                    $res=$connect->query($id_friends_command);
                    
                    while($id_friends = $res->fetch_assoc()) {
                      $friends_data_command= "select username, image_profile from users where user_ID=" . $id_friends['to'];
                      $friends_data = $connect->query($friends_data_command);
                      $name=$friends_data->fetch_assoc();
                      if($search == $name['username']) {
                          echo '<li>';
                          
                          echo'<form action="friendProfile2.php" method="post">
                        <input type="hidden" value="'. $name['image_profile'] . '" name="userimage">' . '
                        <input type="hidden" value="'. $name['username'] . '" name="username">' . '
                        <button type="submit"> <div class="frind">';
                          ?>
                          
                          <img src ="<?php if(isset($name['image_profile'])&&strlen($name['image_profile'])>0){echo 'images/'.$name['image_profile'];}else {echo "images/images.jpg" ;}?> ">
                          <?php
                          echo '<p>'. $name['username'] .'</p>';
                          echo '</div> </button>';
                          echo '</li>';
                          
                          break;
                          
                          }
                          
                      }
                    }
         
                     else {
                      $user_in_session="select user_ID from users where email ='" . $_SESSION['email'] . "'";
                      $q = $connect->query($user_in_session);
                      $user = $q -> fetch_assoc();
                      // select id to all friends
                      $showfriends="select `from` , `to` from relation where status = 'f' and `from` = ".$user['user_ID'];
                      $q_friends = $connect->query($showfriends);
                      while($friends = $q_friends -> fetch_assoc()){
                        //selet image and user name to each friends
                        $data="select username , image_profile from users where user_ID = ".$friends['to'];
                        $q_friend = $connect->query($data);
                        $friend = $q_friend -> fetch_assoc();
                         echo '<li>';
                                  
                      echo'<form action="friendProfile2.php" method="post">
                      <input type="hidden" value="'. $friend['image_profile'] . '" name="userimage">' . '
                      <input type="hidden" value="'. $friend['username'] . '" name="username">' . '
                      <button type="submit" style="margin-bottom:-40px;"> <div class="frind">';
              
                      if(isset($friend['image_profile'])&&strlen($friend['image_profile'])>0){
                        echo '<img src="images/'.$friend['image_profile'] . '">';
                      }else {
                        echo '<img src="images/images.jpg">' ;}
              
                      
                      
                      echo '<p>'. $friend['username'] .'</p>';
                      
                      echo '</div></button></form>';
                      echo '</li>';
                      }} ?>
              </ul>
            </div>
          </div>
          <div id="nav2" style=" display: none" >
            <h6>Friend Request</h6>
            <div class="messages">
              <ul id="mes-frinds">
                <?php
                // //user_id  in the session
                // $sql = "select user_ID from users where email = '" . $_SESSION['email'] . "'";
                // $uid = $connect->query($sql);
                // $uids = $uid->fetch_assoc();
               // select all request that send to me
               $requests="select `from` ,`to` , status from relation where status ='P' and `to` = '".$user_id."'";
               $q_requests = $connect->query($requests);
                while($Results = $q_requests->fetch_assoc()){
                       //get datelies each request from users table
                      $from_details="select username , image_profile from users where user_ID = ".$Results['from'];
                      $q_from_details=$connect->query($from_details);
                      //username and image who send me the request 
                   $from_dateils = $q_from_details->fetch_assoc() ?>
                      <li>
                            <div class="frind">
                              <?php
                                    if(isset($from_dateils['image_profile'])&&strlen($from_dateils['image_profile'])>0){
                                      echo '<img src="images/'.$from_dateils['image_profile'] . '">';
                                    }else {
                                      echo '<img src="images/images.jpg">' ;
                                    }
                                      echo '<p>'. $from_dateils['username'] .'</p>';?>
                                        <span>
                                          <form action="confirm.php" method="post">
                                                  <input type="hidden" name="me" value="<?php echo  $Results['to']?>" >
                                                    <input type="hidden" name="send" value="<?php echo $Results['from']?>" >
                                                    <input type="hidden" name="status" value="F">
                                                    <button class="btn1" type="submit">Confirm</button>
                                           </form> 
                                          <form action="delete.php" method="POST">
                                                <input type="hidden" name="me" value="<?php echo  $Results['to']?>" >
                                                  <input type="hidden" name="send" value="<?php echo $Results['from']?>" >
                                                  <input type="hidden" name="status" value="D">
                                                  <button class="btn2" type="submit">Delete</button>
                                          </form>
                                        </span>
                             </div>
                         
                      </li> <?php }?>
              </ul>
            </div>
          
          
          </div>
      </div>
      </div>
      
      
    </div>
  
  </div>



    <script src="js/jquery-3.6.2.min.js"></script>
    <script>
      $("#bt1").click(function(){
        $("#nav1").show(500);
        $("#nav2").hide(500);

    });
    $("#bt2").on("click",function(){
        $("#nav2").show(500);
        $("#nav1").hide(500);
    });
    </script>
    <!-- <script src="js/frinds.js"></script> -->
    
</body>