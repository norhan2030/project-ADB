<?php
require('connect_DB.php');
session_start();
if($_POST){

    $sql="insert into relation(`from`,`to`,status)values('".$_POST['from']."','".$_POST['to']."','". $_POST['status']."' )";
    $req=$connect->query($sql);
     header('Location:index.php');


}