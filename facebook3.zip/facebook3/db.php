<?php
include('connect_DB.php');

$db = "create database if not exists newfacebook2";
$dbq = $connect->query($db);  

$usedb = "use newfacebook2";
$usedbq = $connect->query($usedb);

$usertable = "create table if not exists users(
    user_ID int primary key AUTO_INCREMENT ,
    username varchar(100) ,
    gender varchar(10) ,
    email varchar(100) ,
    password varchar(100) ,
    work varchar(100) ,
    study varchar(100) ,
    live varchar(100) ,
    image_profile varchar(100) ,
    image_background varchar(100) ,
    `from` varchar(100) ,
    Birthday date ,
    link varchar(100) )";
$usertableq = $connect->query($usertable);

$posttable = "create table if not exists posts(
    id int primary key AUTO_INCREMENT,
    image text ,
    content text ,
    user_id int ,
    foreign key (user_id) references users (user_ID))";
$posttableq = $connect->query($posttable);

$commentstable = "create table if not exists comments(
    id int primary key AUTO_INCREMENT,
    content text ,
    post_id int ,
    foreign key (post_id) references posts (id))";
$commentstableq = $connect->query($commentstable);

$relationtable = "create table if not exists relation(
    `from` int, 
    `to` int, 
    status varchar(4), 
    since datetime NOT NULL DEFAULT current_timestamp(), 
    primary key(`from`, `to`, status))";
$relationtableq = $connect->query($relationtable);
